package app.yoshino.masaki.dcgmanager

class EditActivity {
}